<meta name="viewport" content="width=device-width">

<base href="http://corytishii.com/aau/wnm608/ishii.cory/wnm608/m15/">

<link rel="stylesheet" href="lib/css/styleguide.css">
<link rel="stylesheet" href="lib/css/gridsystem.css">
<link rel="stylesheet" href="css/storetheme.css">

<script src="https://code.jquery.com/jquery-3.4.0.min.js"></script>
<script src="lib/js/functions.js"></script>
<script src="js/templates.js"></script>