<?
function makeAuth() {
	return [
		"localhost",  // database host location name
		"earbudstore", // username database
		"HWN%dUIB2", // password database
		"earbud_store" // database name
	];
}
?>