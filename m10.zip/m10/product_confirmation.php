<?
session_start();
session_destroy();

?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<<title>Ear Audio Store: <?= $product->title ?></title>
	<?include "parts/meta.php" ?>
</head>
<body>
	
	<?include "parts/navbar.php" ?>
	
</body>
</html>