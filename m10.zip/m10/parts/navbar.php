
<header class="navbar">
	<div class="container display-flex">
		<div class="flex-stretch">
			<h1>The Ear Audio Store</h1>
		</div>
		<nav class="nav-flex">
			<ul>
				<li><a href="index.php">Home</a></li>
				<li><a href="product_list.php">Product List</a></li>
				<li><a href="about.php">About Us</a></li>
				<li><a href="product_cart.php">Cart</a></li>
			</ul>
		</nav>
	</div>
	

</header>